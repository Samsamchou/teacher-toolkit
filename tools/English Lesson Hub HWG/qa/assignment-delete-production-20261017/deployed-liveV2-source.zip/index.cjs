"use strict";

const crypto = require("node:crypto");
const { initializeApp } = require("firebase-admin/app");
const { getStorage } = require("firebase-admin/storage");

const { getFirestore, Timestamp } = require("firebase-admin/firestore");
const { defineSecret } = require("firebase-functions/params");
const { HttpsError, onCall } = require("firebase-functions/v2/https");
const { functionsRegion, teacherPasscode } = require("./site-config.generated.cjs");
const {
  ATTEMPT_WINDOW_MS,
  GLOBAL_MAX_ATTEMPTS,
  USER_MAX_ATTEMPTS,
  nextAttempt,
  normalizeAttemptState,
  normalizePasscode,
  passcodesMatch
} = require("./src/access-policy.cjs");
const {
  DEFAULT_SESSION_DURATION_MS,
  MAX_RESULT_IDS_PER_EXPORT,
  createSessionToken,
  normalizeResultIds,
  normalizeSessionToken,
  sessionIdForToken
} = require("./src/teacher-results-session.cjs");
const {
  buildPendingImageDeletes,
  deletePendingTeacherImages
} = require("./src/lesson-image-cleanup.cjs");

initializeApp();

// v2 is opt-in. Default deployment leaves all new endpoints disabled.
const liveAiSecret = defineSecret('LESSON_LIVE_GEMINI_KEY');
const pixabaySecret=defineSecret('LESSON_LIVE_PIXABAY_KEY');
exports.liveImageSearchV2=onCall({region:functionsRegion,enforceAppCheck:true,timeoutSeconds:90,memory:'512MiB',secrets:[pixabaySecret]},async request=>{
  if(process.env.LIVE_V2_ENABLED!=='true'||process.env.LIVE_IMAGE_SEARCH_ENABLED!=='true')throw new HttpsError('failed-precondition','Pixabay 尚未部署啟用。');
  try{const {createCloudImageService}=await import('./src/live-image-service.mjs');const scope=await liveTeacherScope(request,'image');return await createCloudImageService({db:firestore(),key:pixabaySecret.value(),enabled:true,requireTeacher:scope.requireTeacher})(scope.request);}catch(e){if(e instanceof HttpsError)throw e;throw new HttpsError('failed-precondition',e.code?'圖片服務暫時無法使用。':e.message);}
});
exports.liveMediaV2=onCall({region:functionsRegion,enforceAppCheck:true,timeoutSeconds:300,memory:'512MiB'},async request=>{
  if(process.env.LIVE_V2_ENABLED!=='true'||process.env.LIVE_MEDIA_ENABLED!=='true')throw new HttpsError('failed-precondition','雲端素材尚未啟用。');
  try{const {createMediaService}=await import('./src/live-media-service.mjs');const scope=await liveTeacherScope(request,'media');return await createMediaService({db:firestore(),bucket:getStorage().bucket(),requireTeacher:scope.requireTeacher,videoEnabled:process.env.LIVE_VIDEO_ENABLED==='true'})(scope.request);}catch(e){if(e instanceof HttpsError)throw e;throw new HttpsError('failed-precondition','素材處理未完成：'+(e.code?'請檢查授權與檔案狀態。':e.message));}
});
const {onDocumentWritten}=require('firebase-functions/v2/firestore');
exports.liveVideoDispatchV2=onDocumentWritten({region:functionsRegion,document:'liveVideoJobsV2/{id}',retry:false,timeoutSeconds:540},async event=>{
  if(process.env.LIVE_VIDEO_ENABLED!=='true'||event.data?.after.data()?.status!=='queued')return;
  const {dispatchVideoJob,failQueuedVideoDispatch}=await import('./src/live-video-dispatch.mjs');const {GoogleAuth}=require('google-auth-library');
  try{return await dispatchVideoJob({id:event.params.id,workerUrl:process.env.LIVE_WORKER_URL,enabled:true,getClient:audience=>new GoogleAuth().getIdTokenClient(audience)});}catch{
    return {status:await failQueuedVideoDispatch({db:firestore(),id:event.params.id})?'failed':'in-progress'};
  }
});
const {onSchedule}=require('firebase-functions/v2/scheduler');
exports.liveRetentionV2=onSchedule({region:functionsRegion,schedule:'every day 03:10',timeZone:'Asia/Taipei',timeoutSeconds:300},async()=>{
  if(process.env.LIVE_RETENTION_ENABLED!=='true')return;
  const {cleanupLiveRetention}=await import('./src/live-retention.mjs');
  const existing=await cleanupLiveRetention({db:firestore(),bucket:getStorage().bucket(),enabled:true});
  const {cleanupAssignmentRetention}=await import('./src/assignment-retention.mjs');
  const assignments=await cleanupAssignmentRetention({db:firestore(),bucket:getStorage().bucket(),enabled:true});return {existing,assignments};
});
exports.liveV2 = onCall({region:functionsRegion,enforceAppCheck:true,timeoutSeconds:120}, async request => {
  if(process.env.LIVE_V2_ENABLED !== 'true') throw new HttpsError('failed-precondition','雲端 v2 尚未啟用。');
  try {
    const {createLiveService}=await import('./src/live-service.mjs');
    const scope=await liveTeacherScope(request,'live');
    if(String(request.data?.action||'').startsWith('assignment')){const {createAssignmentService}=await import('./src/assignment-service.mjs');const {rateLimit}=await import('./src/live-image-service.mjs');return await createAssignmentService({db:firestore(),requireTeacher:scope.requireTeacher,rateLimit:(uid,action)=>rateLimit(firestore(),uid,action,30),readRecording:async path=>{const f=getStorage().bucket().file(path+'/audio');const [metadata]=await f.getMetadata();return {base64Audio:(await f.download())[0].toString('base64'),mimeType:metadata.contentType};},deleteRecording:async path=>{for(const name of ['audio','score.json'])await getStorage().bucket().file(path+'/'+name).delete({ignoreNotFound:true});}})(scope.request);}
    return await createLiveService({db:firestore(),requireTeacher:scope.requireTeacher})(scope.request);
  } catch(error) {if(error instanceof HttpsError)throw error;throw new HttpsError('failed-precondition',error.message);}
});
exports.liveAudioV2 = onCall({region:functionsRegion,enforceAppCheck:true,timeoutSeconds:180,memory:'512MiB',secrets:[liveAiSecret]}, async request => {
  if(process.env.LIVE_V2_ENABLED!=='true'||process.env.LIVE_AI_ENABLED!=='true')throw new HttpsError('failed-precondition','錄音 AI 尚未經授權啟用。');
  const uid=requireAnonymousCaller(request);
  try {
    const {createAudioWorkflow,geminiScorer}=await import('./src/live-audio.mjs');
    const {audioRepository,audioStorage}=await import('./src/live-audio-repository.mjs');
    if(request.data?.assignment===true){const {assignmentAudioRepository}=await import('./src/assignment-audio-repository.mjs');const run=createAudioWorkflow({repository:assignmentAudioRepository(firestore(),{revision:request.data.revision}),pathPrefix:'assignmentAudioV1',storage:audioStorage(getStorage().bucket()),score:geminiScorer({key:liveAiSecret.value(),model:process.env.LIVE_AI_MODEL,enabled:true})});const result=await run({...request.data,uid});return {status:result.status,attemptId:result.attemptId,result:result.result};}
    const run=createAudioWorkflow({repository:audioRepository(firestore()),storage:audioStorage(getStorage().bucket()),score:geminiScorer({key:liveAiSecret.value(),model:process.env.LIVE_AI_MODEL,enabled:true})});
    const result=await run({...request.data,uid});
    return {status:result.status,result:result.result,best:result.best,passed:result.passed,attemptId:result.attemptId,expiresAt:result.expiresAt};
  } catch(error){throw new HttpsError('failed-precondition',error.message);}
});

function firestore() {
  return getFirestore();
}

async function liveTeacherScope(request,service) {
  const {createTeacherScope}=await import('./src/live-teacher-scope.mjs');
  return createTeacherScope({db:firestore(),requireTeacher:requireTeacherResultsSession})(request,service);
}


const teacherResultsPasscode = defineSecret("TEACHER_RESULTS_PASSCODE");
const ATTEMPT_COLLECTION = "teacherLoginAttempts";
const SESSION_COLLECTION = "teacherResultSessions";
const RESULT_COLLECTION = "practiceResults";
const EXPORT_COLLECTION = "exportEvents";
const LESSON_CONFIG_COLLECTION = "teacherLessonConfigs";
const LESSON_CONFIG_DOCUMENT = "current";
const LESSON_CONFIG_SCHEMA = "teacher-lesson-config-v1";
const MAX_LESSON_CONFIG_BYTES = 900000;
const MAX_LESSON_COUNT = 160;
const MAX_STEPS_PER_LESSON = 80;
const GLOBAL_ATTEMPT_ID = "global";
const ATTEMPT_RECORD_RETENTION_MS = 24 * 60 * 60 * 1000;
const configuredSessionHours = Number(teacherPasscode.sessionHours);
const SESSION_DURATION_MS = Number.isInteger(configuredSessionHours) && configuredSessionHours >= 1 && configuredSessionHours <= 24
  ? configuredSessionHours * 60 * 60 * 1000
  : DEFAULT_SESSION_DURATION_MS;
const configuredResultLimit = Number(teacherPasscode.resultLimit);
const RESULT_LIMIT = Number.isInteger(configuredResultLimit) && configuredResultLimit >= 1 && configuredResultLimit <= MAX_RESULT_IDS_PER_EXPORT
  ? configuredResultLimit
  : MAX_RESULT_IDS_PER_EXPORT;

function timestampMillis(value) {
  return value && typeof value.toMillis === "function" ? value.toMillis() : 0;
}

function attemptState(data) {
  return normalizeAttemptState({
    windowStartedAtMs: timestampMillis(data?.windowStartedAt),
    attemptCount: data?.attemptCount,
    lockedUntilMs: timestampMillis(data?.lockedUntil)
  });
}

function attemptRecord(state, nowMs, scope) {
  const expiresAtMs = Math.max(state.lockedUntilMs || 0, state.windowStartedAtMs + ATTEMPT_WINDOW_MS) + ATTEMPT_RECORD_RETENTION_MS;
  return {
    scope,
    windowStartedAt: Timestamp.fromMillis(state.windowStartedAtMs),
    attemptCount: state.attemptCount,
    lockedUntil: state.lockedUntilMs ? Timestamp.fromMillis(state.lockedUntilMs) : null,
    updatedAt: Timestamp.fromMillis(nowMs),
    expiresAt: Timestamp.fromMillis(expiresAtMs)
  };
}

function requireAnonymousCaller(request) {
  const provider = request.auth?.token?.firebase?.sign_in_provider;
  if (!request.auth || provider !== "anonymous") {
    throw new HttpsError("unauthenticated", "請重新整理頁面後再試。");
  }
  return request.auth.uid;
}

async function reserveAttempt(anonymousUid) {
  const database = firestore();
  const userRef = database.collection(ATTEMPT_COLLECTION).doc(anonymousUid);
  const globalRef = database.collection(ATTEMPT_COLLECTION).doc(GLOBAL_ATTEMPT_ID);
  return database.runTransaction(async (transaction) => {
    const [userSnapshot, globalSnapshot] = await Promise.all([transaction.get(userRef), transaction.get(globalRef)]);
    const nowMs = Date.now();
    const userDecision = nextAttempt(attemptState(userSnapshot.data()), nowMs, { maxAttempts: USER_MAX_ATTEMPTS, windowMs: ATTEMPT_WINDOW_MS });
    if (!userDecision.allowed) {
      throw new HttpsError("resource-exhausted", "嘗試次數過多，請稍後再試。");
    }
    const globalDecision = nextAttempt(attemptState(globalSnapshot.data()), nowMs, { maxAttempts: GLOBAL_MAX_ATTEMPTS, windowMs: ATTEMPT_WINDOW_MS });
    if (!globalDecision.allowed) {
      throw new HttpsError("resource-exhausted", "教師通行碼服務暫時鎖定，請稍後再試。");
    }
    transaction.set(userRef, attemptRecord(userDecision.next, nowMs, "anonymous-user"));
    transaction.set(globalRef, attemptRecord(globalDecision.next, nowMs, "global"));
  });
}

async function clearUserAttempts(anonymousUid) {
  await firestore().collection(ATTEMPT_COLLECTION).doc(anonymousUid).delete();
}

async function createTeacherResultsSession(anonymousUid) {
  const sessionToken = createSessionToken();
  const sessionId = sessionIdForToken(sessionToken);
  const nowMs = Date.now();
  await firestore().collection(SESSION_COLLECTION).doc(sessionId).set({
    schemaVersion: "teacher-results-session-v1",
    anonymousUid,
    createdAt: Timestamp.fromMillis(nowMs),
    lastUsedAt: Timestamp.fromMillis(nowMs),
    expiresAt: Timestamp.fromMillis(nowMs + SESSION_DURATION_MS)
  });
  return sessionToken;
}

async function requireTeacherResultsSession(request) {
  const anonymousUid = requireAnonymousCaller(request);
  const sessionToken = normalizeSessionToken(request.data?.sessionToken);
  const sessionId = sessionIdForToken(sessionToken);
  if (!sessionId) {
    throw new HttpsError("permission-denied", "請先輸入教師通行碼。");
  }
  const sessionRef = firestore().collection(SESSION_COLLECTION).doc(sessionId);
  const snapshot = await sessionRef.get();
  const nowMs = Date.now();
  const expired = timestampMillis(snapshot.data()?.expiresAt) <= nowMs;
  if (!snapshot.exists || snapshot.data()?.anonymousUid !== anonymousUid || expired) {
    if (snapshot.exists && expired) await sessionRef.delete().catch(() => undefined);
    throw new HttpsError("permission-denied", "教師工作階段已結束，請重新輸入通行碼。");
  }
  await sessionRef.set({ lastUsedAt: Timestamp.fromMillis(nowMs) }, { merge: true });
  return { anonymousUid, sessionId, sessionRef };
}



function normalizeLessonConfigVersion(value) {
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= 0 && parsed <= 1000000000 ? parsed : 0;
}

function normalizeLessonConfiguration(value) {
  if (!Array.isArray(value) || value.length > MAX_LESSON_COUNT) {
    throw new HttpsError("invalid-argument", "課程設定格式無效，請重新載入後再試。");
  }
  let json = "";
  try {
    json = JSON.stringify(value);
  } catch {
    throw new HttpsError("invalid-argument", "課程設定無法安全儲存，請移除不支援的內容後再試。");
  }
  if (!json || Buffer.byteLength(json, "utf8") > MAX_LESSON_CONFIG_BYTES) {
    throw new HttpsError("invalid-argument", "課程設定過大，請減少教材內容後再試。");
  }
  const lessons = JSON.parse(json);
  for (const lesson of lessons) {
    if (!lesson || typeof lesson !== "object" || typeof lesson.id !== "string" || lesson.id.length < 1 || lesson.id.length > 120 || !Array.isArray(lesson.steps) || lesson.steps.length > MAX_STEPS_PER_LESSON) {
      throw new HttpsError("invalid-argument", "課程設定格式無效，請重新載入後再試。");
    }
    for (const step of lesson.steps) {
      if (!step || typeof step !== "object" || typeof step.id !== "string" || step.id.length < 1 || step.id.length > 160 || typeof step.type !== "string" || step.type.length > 80) {
        throw new HttpsError("invalid-argument", "課程流程格式無效，請重新載入後再試。");
      }
    }
  }
  return lessons;
}

function lessonConfigResponse(snapshot) {
  if (!snapshot.exists) return { exists: false, version: 0, lessons: [] };
  const data = snapshot.data() || {};
  if (data.schemaVersion !== LESSON_CONFIG_SCHEMA || !Array.isArray(data.lessons)) {
    throw new HttpsError("failed-precondition", "雲端教材資料無法讀取，請聯絡管理者。");
  }
  return {
    exists: true,
    version: normalizeLessonConfigVersion(data.version),
    lessons: normalizeLessonConfiguration(data.lessons)
  };
}

async function loadLessonConfiguration() {
  const reference = firestore().collection(LESSON_CONFIG_COLLECTION).doc(LESSON_CONFIG_DOCUMENT);
  return lessonConfigResponse(await reference.get());
}

async function cleanupQueuedTeacherImages(reference) {
  const latest = await reference.get();
  if (!latest.exists) return { deletedCount: 0, pendingCount: 0 };

  const current = lessonConfigResponse(latest);
  const queuedPaths = buildPendingImageDeletes({
    previousLessons: [],
    nextLessons: current.lessons,
    existingPending: latest.data()?.pendingImageDeletes
  });
  if (!queuedPaths.length) return { deletedCount: 0, pendingCount: 0 };

  const bucket = getStorage().bucket();
  const cleanup = await deletePendingTeacherImages(
    queuedPaths,
    (path) => bucket.file(path).delete({ ignoreNotFound: true })
  );
  if (!cleanup.deletedPaths.length) {
    return { deletedCount: 0, pendingCount: cleanup.failedPaths.length };
  }

  const deleted = new Set(cleanup.deletedPaths);
  const pendingCount = await firestore().runTransaction(async (transaction) => {
    const snapshot = await transaction.get(reference);
    if (!snapshot.exists) return 0;
    const latestConfig = lessonConfigResponse(snapshot);
    const latestPending = buildPendingImageDeletes({
      previousLessons: [],
      nextLessons: latestConfig.lessons,
      existingPending: snapshot.data()?.pendingImageDeletes
    });
    const remaining = latestPending.filter((path) => !deleted.has(path));
    transaction.set(reference, {
      pendingImageDeletes: remaining,
      imageCleanupUpdatedAt: Timestamp.fromMillis(Date.now())
    }, { merge: true });
    return remaining.length;
  });
  return { deletedCount: cleanup.deletedPaths.length, pendingCount };
}

async function saveLessonConfiguration(lessons, expectedVersion) {
  const normalizedLessons = normalizeLessonConfiguration(lessons);
  const requestedVersion = Number(expectedVersion);
  if (!Number.isSafeInteger(requestedVersion) || requestedVersion < 0) {
    throw new HttpsError("invalid-argument", "課程版本無效，請重新載入後再試。");
  }
  const reference = firestore().collection(LESSON_CONFIG_COLLECTION).doc(LESSON_CONFIG_DOCUMENT);
  const saved = await firestore().runTransaction(async (transaction) => {
    const snapshot = await transaction.get(reference);
    const current = lessonConfigResponse(snapshot);
    if (requestedVersion !== current.version) {
      throw new HttpsError("failed-precondition", "雲端教材已在另一台裝置更新；請重新載入後再儲存。");
    }

    let pendingImageDeletes = [];
    try {
      pendingImageDeletes = buildPendingImageDeletes({
        previousLessons: current.lessons,
        nextLessons: normalizedLessons,
        existingPending: snapshot.data()?.pendingImageDeletes
      });
    } catch (error) {
      if (error instanceof RangeError) {
        throw new HttpsError("resource-exhausted", "待刪圖片過多，請分批儲存 Lesson 後再試。");
      }
      throw error;
    }

    const version = current.version + 1;
    transaction.set(reference, {
      schemaVersion: LESSON_CONFIG_SCHEMA,
      version,
      lessons: normalizedLessons,
      pendingImageDeletes,
      updatedAt: Timestamp.fromMillis(Date.now())
    });
    return { version, lessonCount: normalizedLessons.length, pendingImageDeletes };
  });

  let imageCleanup = { deletedCount: 0, pendingCount: saved.pendingImageDeletes.length };
  try {
    imageCleanup = await cleanupQueuedTeacherImages(reference);
  } catch (error) {
    console.warn("Teacher Image Slides cleanup will retry on the next cloud save.", {
      code: String(error?.code || "unknown"),
      pendingCount: saved.pendingImageDeletes.length
    });
  }
  return {
    version: saved.version,
    lessonCount: saved.lessonCount,
    imageCleanup
  };
}
function reportString(value) {
  return typeof value === "string" ? value : "";
}

function reportNumber(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

function reportType(value) {
  return {
    totalQuestions: reportNumber(value?.totalQuestions),
    firstAttemptCorrectCount: reportNumber(value?.firstAttemptCorrectCount),
    finalCorrectCount: reportNumber(value?.finalCorrectCount)
  };
}

function reportResult(snapshot) {
  const data = snapshot.data() || {};
  return {
    id: snapshot.id,
    sessionId: reportString(data.sessionId || snapshot.id),
    studentId: reportString(data.studentId),
    quizId: reportString(data.quizId),
    lessonId: reportString(data.lessonId),
    lessonTitle: reportString(data.lessonTitle),
    bookId: reportString(data.bookId),
    unitId: reportString(data.unitId),
    lessonNumber: reportNumber(data.lessonNumber),
    completedAt: reportString(data.completedAt),
    practiceScore: reportNumber(data.practiceScore),
    practiceMaxScore: reportNumber(data.practiceMaxScore),
    finalCorrectCount: reportNumber(data.finalCorrectCount),
    accuracy: reportNumber(data.accuracy),
    slotScore: reportNumber(data.slotScore),
    typeA: reportType(data.typeA),
    typeB: reportType(data.typeB)
  };
}

async function loadResultsForReport() {
  const snapshot = await firestore().collection(RESULT_COLLECTION).orderBy("completedAt", "desc").limit(RESULT_LIMIT).get();
  return { results: snapshot.docs.map(reportResult), truncated: snapshot.size === RESULT_LIMIT };
}

function normalizeExportFormat(value) {
  return value === "json" ? "json" : value === "csv" ? "csv" : null;
}

function normalizeQueryLabel(value) {
  const candidate = typeof value === "string" ? value.trim() : "all";
  return candidate && candidate.length <= 120 ? candidate : "all";
}

function normalizeExportId(value) {
  const candidate = typeof value === "string" ? value : "";
  return /^[A-Za-z0-9_-]{8,128}$/.test(candidate) ? candidate : null;
}

async function assertResultsExist(resultIds) {
  for (let index = 0; index < resultIds.length; index += 400) {
    const database = firestore();
    const references = resultIds.slice(index, index + 400).map((resultId) => database.collection(RESULT_COLLECTION).doc(resultId));
    const snapshots = await database.getAll(...references);
    if (snapshots.some((snapshot) => !snapshot.exists)) {
      throw new HttpsError("failed-precondition", "部分結果已變更，請重新整理後再匯出。");
    }
  }
}

function functionFailure(error, action) {
  if (error instanceof HttpsError) throw error;
  console.error(`Teacher Results ${action} failed`, { code: String(error?.code || "unknown") });
  throw new HttpsError("internal", "教師成績服務暫時無法使用。");
}

exports.teacherPasscodeLogin = onCall(
  {
    region: functionsRegion,
    timeoutSeconds: 30,
    memory: "256MiB",
    maxInstances: 2,
    secrets: [teacherResultsPasscode]
  },
  async (request) => {
    try {
      const anonymousUid = requireAnonymousCaller(request);
      const passcode = normalizePasscode(request.data?.passcode);
      if (!passcode) throw new HttpsError("invalid-argument", "請輸入六位數教師通行碼。");
      await reserveAttempt(anonymousUid);
      if (!passcodesMatch(passcode, teacherResultsPasscode.value())) {
        throw new HttpsError("permission-denied", "通行碼錯誤。");
      }
      await clearUserAttempts(anonymousUid);
      return { sessionToken: await createTeacherResultsSession(anonymousUid) };
    } catch (error) {
      return functionFailure(error, "login");
    }
  }
);

exports.teacherPasscodeLogout = onCall(
  {
    region: functionsRegion,
    timeoutSeconds: 30,
    memory: "256MiB",
    maxInstances: 2
  },
  async (request) => {
    try {
      const session = await requireTeacherResultsSession(request);
      await session.sessionRef.delete();
      return { signedOut: true };
    } catch (error) {
      return functionFailure(error, "logout");
    }
  }
);



exports.teacherResultsList = onCall(
  {
    region: functionsRegion,
    timeoutSeconds: 30,
    memory: "256MiB",
    maxInstances: 2
  },
  async (request) => {
    try {
      await requireTeacherResultsSession(request);
      return await loadResultsForReport();
    } catch (error) {
      return functionFailure(error, "list");
    }
  }
);

exports.teacherLessonConfigLoad = onCall(
  {
    region: functionsRegion,
    timeoutSeconds: 30,
    memory: "256MiB",
    maxInstances: 2
  },
  async (request) => {
    try {
      await requireTeacherResultsSession(request);
      return await loadLessonConfiguration();
    } catch (error) {
      return functionFailure(error, "lesson-config-load");
    }
  }
);

exports.teacherLessonConfigSave = onCall(
  {
    region: functionsRegion,
    timeoutSeconds: 120,
    memory: "512MiB",
    maxInstances: 2
  },
  async (request) => {
    try {
      await requireTeacherResultsSession(request);
      return await saveLessonConfiguration(request.data?.lessons, request.data?.expectedVersion);
    } catch (error) {
      return functionFailure(error, "lesson-config-save");
    }
  }
);
exports.teacherResultsRecordExport = onCall(
  {
    region: functionsRegion,
    timeoutSeconds: 60,
    memory: "256MiB",
    maxInstances: 2
  },
  async (request) => {
    try {
      const session = await requireTeacherResultsSession(request);
      const format = normalizeExportFormat(request.data?.format);
      const resultIds = normalizeResultIds(request.data?.resultIds, RESULT_LIMIT);
      if (!format || !resultIds) {
        throw new HttpsError("invalid-argument", "匯出資料格式無效，請重新整理後再試。");
      }
      await assertResultsExist(resultIds);
      const exportId = `export-${crypto.randomUUID()}`;
      await firestore().collection(EXPORT_COLLECTION).doc(exportId).set({
        schemaVersion: "teacher-results-export-v1",
        exportId,
        sessionId: session.sessionId,
        anonymousUid: session.anonymousUid,
        format,
        resultIds,
        recordCount: resultIds.length,
        queryLabel: normalizeQueryLabel(request.data?.queryLabel),
        exportedAt: Timestamp.fromMillis(Date.now())
      });
      return { exportId, recordCount: resultIds.length };
    } catch (error) {
      return functionFailure(error, "record-export");
    }
  }
);

exports.teacherResultsDelete = onCall(
  {
    region: functionsRegion,
    timeoutSeconds: 120,
    memory: "512MiB",
    maxInstances: 2
  },
  async (request) => {
    try {
      const session = await requireTeacherResultsSession(request);
      const exportId = normalizeExportId(request.data?.exportId);
      if (!exportId || request.data?.confirmed !== true) {
        throw new HttpsError("invalid-argument", "請先完成匯出並確認刪除。");
      }
      const database = firestore();
      const exportRef = database.collection(EXPORT_COLLECTION).doc(exportId);
      const exportSnapshot = await exportRef.get();
      const exportRecord = exportSnapshot.data();
      if (!exportSnapshot.exists || exportRecord?.sessionId !== session.sessionId || exportRecord?.anonymousUid !== session.anonymousUid) {
        throw new HttpsError("permission-denied", "找不到本次工作階段的匯出紀錄。");
      }
      if (exportRecord.deletedAt) return { deleted: 0, alreadyDeleted: true };
      const resultIds = normalizeResultIds(exportRecord.resultIds, RESULT_LIMIT);
      if (!resultIds) throw new HttpsError("failed-precondition", "匯出紀錄無法用於刪除，請重新匯出。");
      for (let index = 0; index < resultIds.length; index += 400) {
        const batch = database.batch();
        resultIds.slice(index, index + 400).forEach((resultId) => batch.delete(database.collection(RESULT_COLLECTION).doc(resultId)));
        await batch.commit();
      }
      await exportRef.set({ deletedAt: Timestamp.fromMillis(Date.now()) }, { merge: true });
      return { deleted: resultIds.length };
    } catch (error) {
      return functionFailure(error, "delete");
    }
  }
);

const configuredFunctionsMatch = teacherPasscode.secretName === "TEACHER_RESULTS_PASSCODE"
  && teacherPasscode.loginFunction === "teacherPasscodeLogin"
  && teacherPasscode.logoutFunction === "teacherPasscodeLogout"
  && teacherPasscode.listFunction === "teacherResultsList"
  && teacherPasscode.recordExportFunction === "teacherResultsRecordExport"
  && teacherPasscode.deleteFunction === "teacherResultsDelete";
if (!configuredFunctionsMatch) {
  throw new Error("Teacher Results function configuration does not match the exported functions.");
}

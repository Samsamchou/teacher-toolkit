// Seeded generator from GPT Sites games/src/plinkoh-model.mjs. Source remains unchanged.
export const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
export function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s += 0x6d2b79f5;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
